<div class="section section_padding dfsectionrealitybg">
	<div class="dfcontainer">
		<div class="dfreality dfreality_theme_rose">
			<h2 class="h2 h2_theme_rosa h2_dark dfreality__caption">Что это значит в <br> действительности?</h2>
			<p class="dfreality__textbox dfreality__textbox_theme_margin">Это говорит о том, что теперь каждая продажа товара или оплата любой услуги будет в режиме онлайн регистрироваться в органах ФНС России. <span class="dfreality__height"></span>		
			Покупатели смогут сразу же получать распечатанный чек, либо его электронный вариант в виде смс или письма на почту. <span class="dfreality__height"></span>		
			Поправки в закон также означают, что до 1 июля</p>
			<p class="dfreality__textbox">2017 года все владельцы касс обязаны приобрести технику нового образца, в которых модуль ЭКЛЗ заменит фискальный накопитель, либо провести модернизацию своей техники — заменить устаревший ЭКЛЗ на новый ФН, который и будет отвечать за шифрование и передачу в Налоговую службы данных о транзакции.</p>
		</div>	
	</div>
</div>			
