<div class="section section_padding secure">
	<div class="container secure__container">
		<center><h2 class="h2 h2_theme_rosa h2_white secure-title">Обезопасьте работу своей 
контрольно-кассовой техники!</h2></center>
		<span class="subtitle subtitle_theme_rosa subtitle_white secure-subtitle">Закажите <span>БЕСПЛАТНУЮ</span> консультацию у наших экспертов по выбору или модернизации ваших касс:</span>
		<div class="secure__form">
			<form action="#" method="post" class="form1 theme__rosa__form-block">
				<span class="input input_theme_rosa theme__rosa__form-input"><input type="text" class="input__control" name="uname" placeholder="Ваше имя"></span> 
				<span class="input input_theme_rosa theme__rosa__form-input"><input type="tel" class="input__control js-phone" name="phone" placeholder="Номер телефона" required></span>
				<input type="submit" class="button button_theme_rosa button_red button_connect" value="Свяжитесь со мной">
			</form>
		</div>
	</div>
</div>