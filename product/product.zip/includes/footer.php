
<script>
	$(document).ready(function() {
		$("head").append("<link href='https://fonts.googleapis.com/css?family=Fira+Sans+Condensed:300i,500,600,700&amp;subset=cyrillic' rel='stylesheet'>");
		$("head").append("<link href='//netdna.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.css' rel='stylesheet'>");

	});
</script>

<script src="libs/jquery/jquery-1.11.1.min.js"></script>
<script src="libs/owl.carousel/owl.carousel.js"></script>
<script src="libs/fancybox/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.mousewheel.js"></script>
<script src="js/responsiveTabs.js"></script>
<script src="js/jquery.maskedinput.min.js"></script>
<script src="js/common.js"></script>