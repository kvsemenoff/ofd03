<div class="header-top">
	<div class="container">
		<div class="row">
			<div class="col-md-7 no-padding">
				<div class="header-top__title">
					<span class="header-top__title_view">Работа касс в автономной зоне: </span>
					<p class="header-top__title_view header-top__title_view_p">нюансы применения нового ФЗ-54</p>
					<a href="#" class="button button_theme_rosa button_red button_pick">Подобрать оборудование</a> <span class="header-top__title_el">или</span> <a class="header-top__title_el el__2" href="#">Задать вопрос специалисту</a>
				</div>
			</div>
			<div class="col-md-5">
				<div class="header-top__img">
					<img src="img/header-icon.png" alt="">
				</div>
			</div>
		</div>
	</div>
</div>