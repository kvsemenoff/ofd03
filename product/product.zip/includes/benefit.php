<div class="section section_padding">
	<div class="dfbenefit dfbenefit_theme_rose">

		<div class="dfbenefit__leftblock dfbenefit__leftblock_theme_rose">
			<h2 class="h2 h2_theme_rosa h2_white dfbenefit__caption">Кому это будет выгодно?</h2><div class="clearfix"></div>
			<span class="dfbenefit__subtitle">По словам представителей Налоговой  службы, нововведение позволит:</span>	
			<div class="clearfix"></div>			
		</div>

		<div class="dfbenefit__rightblock dfbenefit__rightblock_theme_rose">
			<div class="dfbenefit__txtbox">
				<div class="dfbenefit__txtbox__img">
					<img src="img/wallet.png" alt="">
				</div>
				<p class="dfbenefit__txtbox__text">Cнизить ежегодные расходы <br> на ККТ</p>
			</div>	
			<div class="dfbenefit__txtbox">
				<div class="dfbenefit__txtbox__img">
					<img src="img/tech.png" alt="">
				</div>
				<p class="dfbenefit__txtbox__text">Применять в составе ККТ современные электронные устройства – мобильные телефоны и планшеты</p>
			</div>	
			<div class="dfbenefit__txtbox">
				<div class="dfbenefit__txtbox__img">
					<img src="img/list.png" alt="">
				</div>
				<p class="dfbenefit__txtbox__text">Иметь возможность через сайт ФНС России зарегистрировать ККТ без ее физического предоставления в налоговый орган</p>
			</div>	
			<div class="dfbenefit__txtbox">
				<div class="dfbenefit__txtbox__img">
					<img src="img/search.png" alt="" >
				</div>
				<p class="dfbenefit__txtbox__text">Избавиться от проверок, так как оперативное получение информации о расчетах обеспечивает соответствующую среду доверия</p>
			</div>	
			<div class="dfbenefit__txtbox">	
				<div class="dfbenefit__txtbox__img">
					<img src="img/graph.png" alt="">			
				</div>
				<p class="dfbenefit__txtbox__text">Получить инструмент, с помощью которого предприниматель сможет в режиме реального времени следить за своими оборотами, показателями, и лучше контролировать свой бизнес</p>
			</div>	
			<div class="dfbenefit__txtbox">
				<div class="dfbenefit__txtbox__img">
					<img src="img/balance.png" alt="">
				</div>
				<p class="dfbenefit__txtbox__text">Работать в условиях честной конкурентной бизнес среды за счет пресечения возможности недобросовестных налогоплательщиков незаконно минимизировать свои налоговые обязательства и нечестно получать конкурентное преимущество</p>
			</div>	
		</div>
		<div class="clearfix"></div>
	</div>
</div>			