<?php require_once('includes/header.php'); ?>
<?php require_once('includes/header-top.php'); ?>

<?php require_once('includes/changes.php'); ?>
<?php require_once('includes/reality.php'); ?>
<?php require_once('includes/benefit.php'); ?>
<?php require_once('includes/secure.php'); ?>

<?php require_once('includes/autonomous.php'); ?>
<?php require_once('includes/another.php'); ?>
<?php require_once('includes/osnov.php'); ?>
<?php require_once('includes/questions.php'); ?>

<?php require_once('includes/footer.php'); ?>
</body>
</html>
